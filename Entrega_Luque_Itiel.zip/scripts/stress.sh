#!/bin/bash

for i in {1..20}
do
   python select.py &
done